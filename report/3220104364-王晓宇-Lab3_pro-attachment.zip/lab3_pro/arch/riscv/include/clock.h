#include "stdint.h"
#include "sbi.h"

uint64_t get_cycles();

void clock_set_next_event();