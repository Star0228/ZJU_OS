#ifndef __STRING_H__
#define __STRING_H__

#include "stdint.h"

void *memset(void *, int, uint64_t);

void *memcpy(void *, void *, uint64_t);

#endif
